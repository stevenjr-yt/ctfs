<?php
// JWT Algorithm Confusion
// Changing RS256 to HS256.
// Flag is in the source code somewhere...
// FLAG: DCSC{REDACTED}
echo "Welcome to JWT Algorithm Confusion. Can you find the flag?";
?>