<?php
// SSTI
// Server-Side Template Injection (Jinja2) to RCE.
// Flag is in the source code somewhere...
// FLAG: DCSC{REDACTED}
echo "Welcome to SSTI. Can you find the flag?";
?>