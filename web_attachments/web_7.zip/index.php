<?php
// Prototype Pollution
// NodeJS vulnerability leading to auth bypass.
// Flag is in the source code somewhere...
// FLAG: DCSC{REDACTED}
echo "Welcome to Prototype Pollution. Can you find the flag?";
?>