<?php
// Race Condition (TOCTOU)
// Coupon redemption exploit.
// Flag is in the source code somewhere...
// FLAG: DCSC{REDACTED}
echo "Welcome to Race Condition (TOCTOU). Can you find the flag?";
?>